var struct_object =
[
    [ "Object", "struct_object.html#a088289e66d54118fab19bc14562e984a", null ],
    [ "~Object", "struct_object.html#a76a965ef29237a6c9a20689d1b2d94cf", null ],
    [ "inner", "struct_object.html#ac38871dc7fe98150d5456c389f98cf53", null ],
    [ "inner_const_ref", "struct_object.html#acff34dc7398999f3befc401d4334cf8d", null ],
    [ "inner_ref", "struct_object.html#a0818b8c3dc4c1f1447548b2f2a7981df", null ]
];