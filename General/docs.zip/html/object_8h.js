var object_8h =
[
    [ "ObjectBase", "struct_object_base.html", null ],
    [ "Object< T >", "struct_object.html", "struct_object" ],
    [ "get_inner", "object_8h.html#a2e8678b359eb0c6e3ba4183b4513f6a3", null ],
    [ "get_inner_const_ref", "object_8h.html#af39aac265968f30cbafb1ab7c8a9eda7", null ],
    [ "get_inner_ref", "object_8h.html#a26bdf03d862a7d65750e510d51688865", null ],
    [ "make_param", "object_8h.html#aad5e1940c28790ef9089b75882dabb9f", null ]
];