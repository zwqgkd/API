var files_dup =
[
    [ "general.cpp", "general_8cpp.html", "general_8cpp" ],
    [ "object.h", "object_8h.html", "object_8h" ]
];