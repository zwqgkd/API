var searchData=
[
  ['read_0',['read',['../general_8cpp.html#aae06283b39be72aa3e846a5b08d9e185',1,'general.cpp']]]
];
