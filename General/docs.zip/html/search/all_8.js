var searchData=
[
  ['show_0',['show',['../general_8cpp.html#a640eeafcd30cd14f0eb671ffd9b281e5',1,'general.cpp']]]
];
