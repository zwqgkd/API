var general_8cpp =
[
    [ "convert_color", "general_8cpp.html#afe942dd588ef49866161a7a32a293ce2", null ],
    [ "draw_contours", "general_8cpp.html#aad01a50711bfc6f6122f7ce9a49c5f35", null ],
    [ "find_contours", "general_8cpp.html#a73459987ea333d0a1013df307a617ae8", null ],
    [ "median_blur", "general_8cpp.html#ab43aea11fa4a9f4563c4514651fc96cb", null ],
    [ "morph_close", "general_8cpp.html#a188c635a846c9d4e96bdb8fd9b7056c6", null ],
    [ "morph_open", "general_8cpp.html#a60aaf77339364656d7ae54f4c2026c8a", null ],
    [ "read", "general_8cpp.html#aae06283b39be72aa3e846a5b08d9e185", null ],
    [ "show", "general_8cpp.html#a640eeafcd30cd14f0eb671ffd9b281e5", null ],
    [ "threshold", "general_8cpp.html#a9c28e6c9bea26ebb79221b20b2fe4a66", null ]
];