var annotated_dup =
[
    [ "Object", "struct_object.html", "struct_object" ],
    [ "ObjectBase", "struct_object_base.html", null ]
];