var searchData=
[
  ['make_5fparam_0',['make_param',['../object_8h.html#aad5e1940c28790ef9089b75882dabb9f',1,'object.h']]],
  ['median_5fblur_1',['median_blur',['../general_8cpp.html#ab43aea11fa4a9f4563c4514651fc96cb',1,'general.cpp']]],
  ['morph_5fclose_2',['morph_close',['../general_8cpp.html#a188c635a846c9d4e96bdb8fd9b7056c6',1,'general.cpp']]],
  ['morph_5fopen_3',['morph_open',['../general_8cpp.html#a60aaf77339364656d7ae54f4c2026c8a',1,'general.cpp']]]
];
