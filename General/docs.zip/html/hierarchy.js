var hierarchy =
[
    [ "ObjectBase", "struct_object_base.html", [
      [ "Object< T >", "struct_object.html", null ]
    ] ]
];