var searchData=
[
  ['object_0',['Object',['../struct_object.html',1,'Object&lt; T &gt;'],['../struct_object.html#a088289e66d54118fab19bc14562e984a',1,'Object::Object()']]],
  ['object_2eh_1',['object.h',['../object_8h.html',1,'']]],
  ['objectbase_2',['ObjectBase',['../struct_object_base.html',1,'']]]
];
